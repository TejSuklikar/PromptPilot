import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import NavBar from './components/NavBar';
import HomePage from './components/HomePage';
import AccountPage from './components/AccountPage';
import AuthModal from './components/AuthModal';
import './index.css';

/**
 * Main App Component - PromptPilot Dashboard
 * 
 * Handles routing and provides authentication context
 */
function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-900">
          <NavBar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/account" element={<AccountPage />} />
            <Route path="/auth" element={<AuthModal />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;