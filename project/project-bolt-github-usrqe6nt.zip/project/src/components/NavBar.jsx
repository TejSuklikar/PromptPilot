import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

/**
 * NavBar Component - Top navigation with techy dark styling
 * 
 * Features navigation links and user authentication status
 */
const NavBar = () => {
  const location = useLocation();
  const { user, logout } = useAuth();

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="bg-gray-800 border-b border-gray-700 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          
          {/* Logo/Brand */}
          <div className="flex items-center">
            <Link to="/" className="text-white font-bold text-xl tracking-wide text-shadow-glow">
              PROMPTPILOT
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-8">
            <Link
              to="/"
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                isActive('/') 
                  ? 'text-blue-400 bg-gray-700' 
                  : 'text-gray-200 hover:text-blue-300 hover:bg-gray-700'
              }`}
            >
              Home
            </Link>
            
            {user && (
              <Link
                to="/account"
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  isActive('/account') 
                    ? 'text-blue-400 bg-gray-700' 
                    : 'text-gray-200 hover:text-blue-300 hover:bg-gray-700'
                }`}
              >
                Account
              </Link>
            )}

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="text-gray-300 text-sm">
                    {user.email}
                  </span>
                  <button
                    onClick={logout}
                    className="text-gray-400 hover:text-white text-sm font-medium transition-colors duration-200"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <Link
                  to="/auth"
                  className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-4 py-2 rounded-md text-sm font-medium hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300"
                >
                  Sign In
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;