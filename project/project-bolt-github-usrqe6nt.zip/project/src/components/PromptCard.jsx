import React from 'react';

/**
 * PromptCard Component - Techy Dark Theme with Improved Typography
 * 
 * A cyberpunk-inspired card component for prompt evaluation with enhanced readability.
 * Features Inter font family for optimal legibility and improved text contrast.
 */
const PromptCard = ({ 
  prompt, 
  onPromptChange, 
  onScoreClick, 
  score, 
  suggestion 
}) => {
  return (
    <div className="w-full max-w-lg mx-auto">
      {/* Main Card Container - Dark theme with neon border */}
      <div className="bg-gray-800 border-2 border-blue-500 rounded-lg shadow-2xl shadow-blue-900/50 p-8 space-y-8">
        
        {/* Card Header - Enhanced typography with better readability */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-3 tracking-wide text-shadow-glow">
            PROMPTPILOT
          </h1>
          <p className="text-gray-200 text-sm font-medium uppercase tracking-wider">
            AI-Powered Prompt Analysis System
          </p>
        </div>

        {/* Prompt Input Section */}
        <div className="space-y-4">
          <label 
            htmlFor="prompt-input" 
            className="block text-sm font-semibold text-gray-200 uppercase tracking-wide"
          >
            Enter Prompt Sequence:
          </label>
          <textarea
            id="prompt-input"
            value={prompt}
            onChange={(e) => onPromptChange(e.target.value)}
            placeholder="Initialize your prompt parameters here... Be precise and define expected output protocols."
            className="w-full min-h-32 p-4 bg-gray-700 border border-gray-600 rounded-md 
                     text-gray-50 placeholder-gray-300 font-normal leading-relaxed
                     focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:outline-none
                     resize-vertical transition-all duration-300
                     hover:border-gray-500"
            rows={4}
          />
        </div>

        {/* Score Button - Enhanced typography */}
        <div className="flex justify-center">
          <button
            onClick={onScoreClick}
            disabled={!prompt || prompt.trim().length === 0}
            className="px-8 py-3 bg-gradient-to-r from-blue-500 to-cyan-400 text-white 
                     font-semibold rounded-md tracking-wide uppercase text-sm
                     hover:shadow-lg hover:shadow-cyan-500/50 
                     focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2 focus:ring-offset-gray-800
                     disabled:bg-gray-600 disabled:cursor-not-allowed disabled:shadow-none
                     transition-all duration-300 transform hover:scale-105
                     min-w-40"
          >
            {score !== null ? 'Re-Analyze' : 'Execute Scan'}
          </button>
        </div>

        {/* Results Section - Enhanced readability */}
        {(score !== null || suggestion) && (
          <div className="border-t border-gray-700 pt-8 space-y-6">
            
            {/* Score Display - Improved contrast and readability */}
            {score !== null && (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 
                              rounded-full bg-gray-900 border-2 border-green-400
                              shadow-lg shadow-green-400/30">
                  <span className="text-green-400 font-bold text-2xl text-shadow-green">
                    {score}
                  </span>
                </div>
                <p className="mt-3 text-xs text-gray-300 font-medium uppercase tracking-widest">
                  Optimization Score
                </p>
                
                {/* Score Status Indicator - Better text contrast */}
                <div className="mt-2">
                  {score >= 80 ? (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold 
                                   bg-green-900/50 text-green-200 border border-green-500/30">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                      OPTIMAL
                    </span>
                  ) : score >= 60 ? (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold 
                                   bg-yellow-900/50 text-yellow-200 border border-yellow-500/30">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full mr-2 animate-pulse"></div>
                      MODERATE
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold 
                                   bg-red-900/50 text-red-200 border border-red-500/30">
                      <div className="w-2 h-2 bg-red-400 rounded-full mr-2 animate-pulse"></div>
                      REQUIRES OPTIMIZATION
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Suggestion Display - Enhanced readability */}
            {suggestion && (
              <div className="bg-gray-900/50 rounded-md p-5 border border-cyan-500/30 
                            shadow-lg shadow-cyan-900/20">
                <h3 className="text-sm font-semibold text-cyan-200 mb-3 flex items-center uppercase tracking-wide">
                  <svg className="w-4 h-4 mr-2 text-cyan-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  System Recommendation
                </h3>
                <p className="text-cyan-100 text-sm leading-relaxed font-normal">
                  {suggestion}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Tech-style footer accent */}
        <div className="flex justify-center pt-4">
          <div className="flex space-x-1">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromptCard;