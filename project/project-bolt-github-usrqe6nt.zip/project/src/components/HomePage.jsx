import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import PromptCard from './PromptCard';

/**
 * HomePage Component - Main dashboard with PromptCard and user status
 * 
 * Shows the prompt evaluation tool and user credit information
 */
const HomePage = () => {
  const { user, useCredit } = useAuth();
  const [prompt, setPrompt] = React.useState('');
  const [score, setScore] = React.useState(null);
  const [suggestion, setSuggestion] = React.useState(null);

  const handleScoreClick = () => {
    // Check if user has credits (if logged in)
    if (user && !useCredit()) {
      alert('No credits remaining. Please upgrade to Pro for unlimited evaluations.');
      return;
    }

    // Simulate API call with random score and suggestion
    const randomScore = Math.floor(Math.random() * 101);
    const suggestions = [
      "Consider being more specific about the desired output format.",
      "Add context about your target audience for better results.",
      "Include examples to clarify your expectations.",
      "Break down complex requests into smaller, focused prompts.",
      "Specify the tone and style you want in the response."
    ];
    
    setScore(randomScore);
    
    // Only show suggestion if score is below 80
    if (randomScore < 80) {
      setSuggestion(suggestions[Math.floor(Math.random() * suggestions.length)]);
    } else {
      setSuggestion(null);
    }
  };

  const handlePromptChange = (newPrompt) => {
    setPrompt(newPrompt);
    // Reset results when prompt changes
    setScore(null);
    setSuggestion(null);
  };

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4">
        
        {/* Main PromptCard */}
        <div className="mb-12">
          <PromptCard
            prompt={prompt}
            onPromptChange={handlePromptChange}
            onScoreClick={handleScoreClick}
            score={score}
            suggestion={suggestion}
          />
        </div>

        {/* User Status Section */}
        <div className="flex justify-center">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 max-w-md w-full">
            {user ? (
              // Logged in user status
              <div className="text-center">
                <h3 className="text-white font-semibold mb-3">Account Status</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300 text-sm">Plan:</span>
                    <span className="text-blue-400 font-medium capitalize">
                      {user.plan === 'free' ? 'Free' : 'Pro'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300 text-sm">Evaluations:</span>
                    <span className="text-green-400 font-medium">
                      {user.plan === 'free' ? `${user.credits} remaining` : 'Unlimited'}
                    </span>
                  </div>
                  {user.plan === 'free' && user.credits <= 5 && (
                    <div className="mt-4 p-3 bg-yellow-900/30 border border-yellow-500/30 rounded-md">
                      <p className="text-yellow-200 text-xs text-center">
                        Running low on credits! 
                        <Link to="/account" className="text-yellow-400 hover:text-yellow-300 ml-1 underline">
                          Upgrade to Pro
                        </Link>
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              // Not logged in
              <div className="text-center">
                <h3 className="text-white font-semibold mb-3">Get Started</h3>
                <p className="text-gray-300 text-sm mb-4">
                  Create an account to track your evaluations and get 15 free credits.
                </p>
                <Link
                  to="/auth"
                  className="inline-block bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-6 py-2 rounded-md font-medium hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 transform hover:scale-105"
                >
                  Create Account
                </Link>
                <p className="text-gray-400 text-xs mt-3">
                  No credit card required
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;